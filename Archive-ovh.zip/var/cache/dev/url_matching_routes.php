<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/admin/email-account' => [[['_route' => 'admin_email_account_index', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::index', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'index'], null, ['GET' => 0], null, false, false, null]],
        '/admin/email-account/new' => [[['_route' => 'admin_email_account_new', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::new', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/email-account/batch-delete' => [[['_route' => 'admin_email_account_batch_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::batchDelete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'batchDelete'], null, ['POST' => 0], null, false, false, null]],
        '/admin/email-account/autocomplete' => [[['_route' => 'admin_email_account_autocomplete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::autocomplete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'autocomplete'], null, ['GET' => 0], null, false, false, null]],
        '/admin/email-account/render-filters' => [[['_route' => 'admin_email_account_render_filters', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::renderFilters', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'renderFilters'], null, ['GET' => 0], null, false, false, null]],
        '/admin/redirection' => [[['_route' => 'admin_redirection_index', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::index', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'index'], null, ['GET' => 0], null, false, false, null]],
        '/admin/redirection/new' => [[['_route' => 'admin_redirection_new', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::new', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/redirection/batch-delete' => [[['_route' => 'admin_redirection_batch_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::batchDelete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'batchDelete'], null, ['POST' => 0], null, false, false, null]],
        '/admin/redirection/autocomplete' => [[['_route' => 'admin_redirection_autocomplete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::autocomplete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'autocomplete'], null, ['GET' => 0], null, false, false, null]],
        '/admin/redirection/render-filters' => [[['_route' => 'admin_redirection_render_filters', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::renderFilters', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'renderFilters'], null, ['GET' => 0], null, false, false, null]],
        '/admin/responder' => [[['_route' => 'admin_responder_index', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::index', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'index'], null, ['GET' => 0], null, false, false, null]],
        '/admin/responder/new' => [[['_route' => 'admin_responder_new', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::new', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/responder/batch-delete' => [[['_route' => 'admin_responder_batch_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::batchDelete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'batchDelete'], null, ['POST' => 0], null, false, false, null]],
        '/admin/responder/autocomplete' => [[['_route' => 'admin_responder_autocomplete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::autocomplete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'autocomplete'], null, ['GET' => 0], null, false, false, null]],
        '/admin/responder/render-filters' => [[['_route' => 'admin_responder_render_filters', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::renderFilters', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'renderFilters'], null, ['GET' => 0], null, false, false, null]],
        '/admin/user' => [[['_route' => 'admin_user_index', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::index', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'index'], null, ['GET' => 0], null, false, false, null]],
        '/admin/user/new' => [[['_route' => 'admin_user_new', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::new', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/user/batch-delete' => [[['_route' => 'admin_user_batch_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::batchDelete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'batchDelete'], null, ['POST' => 0], null, false, false, null]],
        '/admin/user/autocomplete' => [[['_route' => 'admin_user_autocomplete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::autocomplete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'autocomplete'], null, ['GET' => 0], null, false, false, null]],
        '/admin/user/render-filters' => [[['_route' => 'admin_user_render_filters', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::renderFilters', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'renderFilters'], null, ['GET' => 0], null, false, false, null]],
        '/admin' => [[['_route' => 'admin', '_controller' => 'App\\Controller\\Admin\\DashboardController::index'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'app_home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null]],
        '/ovh/email/sync' => [[['_route' => 'ovh_email_sync', '_controller' => 'App\\Controller\\OvhEmailController::sync'], null, ['GET' => 0], null, false, false, null]],
        '/ovh/responder/sync-all' => [[['_route' => 'ovh_responder_sync_all', '_controller' => 'App\\Controller\\OvhResponderController::syncAllResponders'], null, ['GET' => 0], null, false, false, null]],
        '/forgot-password' => [[['_route' => 'app_forgot_password', '_controller' => 'App\\Controller\\PasswordResetController::forgot'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/admin/(?'
                    .'|email\\-account/([^/]++)(?'
                        .'|/(?'
                            .'|edit(*:51)'
                            .'|delete(*:64)'
                        .')'
                        .'|(*:72)'
                    .')'
                    .'|re(?'
                        .'|direction/([^/]++)(?'
                            .'|/(?'
                                .'|edit(*:114)'
                                .'|delete(*:128)'
                            .')'
                            .'|(*:137)'
                        .')'
                        .'|sponder/([^/]++)(?'
                            .'|/(?'
                                .'|edit(*:173)'
                                .'|delete(*:187)'
                            .')'
                            .'|(*:196)'
                        .')'
                    .')'
                    .'|user/([^/]++)(?'
                        .'|/(?'
                            .'|edit(*:230)'
                            .'|delete(*:244)'
                        .')'
                        .'|(*:253)'
                    .')'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:291)'
                .'|/ovh/(?'
                    .'|email/([^/]++)/account(?'
                        .'|s(*:333)'
                        .'|/([^/]++)(?'
                            .'|(*:353)'
                            .'|/usage(*:367)'
                        .')'
                    .')'
                    .'|responder/(?'
                        .'|get/([^/]++)/([^/]++)(*:411)'
                        .'|create/([^/]++)(*:434)'
                        .'|update/([^/]++)/([^/]++)(*:466)'
                        .'|delete/([^/]++)/([^/]++)(*:498)'
                        .'|sync/([^/]++)(*:519)'
                    .')'
                    .'|test/(?'
                        .'|usage/([^/]++)/([^/]++)(*:559)'
                        .'|account/([^/]++)/([^/]++)(*:592)'
                    .')'
                .')'
                .'|/reset\\-password/([^/]++)(*:627)'
                .'|/test/ovh/redirections/([^/]++)(*:666)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        51 => [[['_route' => 'admin_email_account_edit', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::edit', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'edit'], ['entityId'], ['GET' => 0, 'POST' => 1, 'PATCH' => 2], null, false, false, null]],
        64 => [[['_route' => 'admin_email_account_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::delete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'delete'], ['entityId'], ['POST' => 0], null, false, false, null]],
        72 => [[['_route' => 'admin_email_account_detail', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\EmailAccountCrudController::detail', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\EmailAccountCrudController', 'crudAction' => 'detail'], ['entityId'], ['GET' => 0], null, false, true, null]],
        114 => [[['_route' => 'admin_redirection_edit', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::edit', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'edit'], ['entityId'], ['GET' => 0, 'POST' => 1, 'PATCH' => 2], null, false, false, null]],
        128 => [[['_route' => 'admin_redirection_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::delete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'delete'], ['entityId'], ['POST' => 0], null, false, false, null]],
        137 => [[['_route' => 'admin_redirection_detail', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\RedirectionCrudController::detail', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\RedirectionCrudController', 'crudAction' => 'detail'], ['entityId'], ['GET' => 0], null, false, true, null]],
        173 => [[['_route' => 'admin_responder_edit', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::edit', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'edit'], ['entityId'], ['GET' => 0, 'POST' => 1, 'PATCH' => 2], null, false, false, null]],
        187 => [[['_route' => 'admin_responder_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::delete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'delete'], ['entityId'], ['POST' => 0], null, false, false, null]],
        196 => [[['_route' => 'admin_responder_detail', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\ResponderCrudController::detail', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\ResponderCrudController', 'crudAction' => 'detail'], ['entityId'], ['GET' => 0], null, false, true, null]],
        230 => [[['_route' => 'admin_user_edit', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::edit', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'edit'], ['entityId'], ['GET' => 0, 'POST' => 1, 'PATCH' => 2], null, false, false, null]],
        244 => [[['_route' => 'admin_user_delete', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::delete', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'delete'], ['entityId'], ['POST' => 0], null, false, false, null]],
        253 => [[['_route' => 'admin_user_detail', '_locale' => 'en', '_controller' => 'App\\Controller\\Admin\\UserCrudController::detail', 'routeCreatedByEasyAdmin' => true, 'dashboardControllerFqcn' => 'App\\Controller\\Admin\\DashboardController', 'crudControllerFqcn' => 'App\\Controller\\Admin\\UserCrudController', 'crudAction' => 'detail'], ['entityId'], ['GET' => 0], null, false, true, null]],
        291 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        333 => [[['_route' => 'ovh_email_list_accounts', '_controller' => 'App\\Controller\\OvhEmailController::listAccounts'], ['domain'], ['GET' => 0], null, false, false, null]],
        353 => [[['_route' => 'ovh_email_account_details', '_controller' => 'App\\Controller\\OvhEmailController::accountDetails'], ['domain', 'accountName'], ['GET' => 0], null, false, true, null]],
        367 => [[['_route' => 'ovh_email_account_usage', '_controller' => 'App\\Controller\\OvhEmailController::accountUsage'], ['domain', 'accountName'], ['GET' => 0], null, false, false, null]],
        411 => [[['_route' => 'ovh_responder_get', '_controller' => 'App\\Controller\\OvhResponderController::getResponder'], ['domain', 'account'], ['GET' => 0], null, false, true, null]],
        434 => [[['_route' => 'ovh_responder_create', '_controller' => 'App\\Controller\\OvhResponderController::createResponder'], ['domain'], ['POST' => 0], null, false, true, null]],
        466 => [[['_route' => 'ovh_responder_update', '_controller' => 'App\\Controller\\OvhResponderController::updateResponder'], ['domain', 'account'], ['PUT' => 0], null, false, true, null]],
        498 => [[['_route' => 'ovh_responder_delete', '_controller' => 'App\\Controller\\OvhResponderController::deleteResponder'], ['domain', 'account'], ['DELETE' => 0], null, false, true, null]],
        519 => [[['_route' => 'ovh_responder_sync_one', '_controller' => 'App\\Controller\\OvhResponderController::syncOneResponder'], ['emailAccountId'], ['GET' => 0], null, false, true, null]],
        559 => [[['_route' => 'ovh_test_usage', '_controller' => 'App\\Controller\\OvhTestController::testUsage'], ['domain', 'accountName'], ['GET' => 0], null, false, true, null]],
        592 => [[['_route' => 'ovh_test_account', '_controller' => 'App\\Controller\\OvhTestController::testAccount'], ['domain', 'accountName'], ['GET' => 0], null, false, true, null]],
        627 => [[['_route' => 'app_reset_password', '_controller' => 'App\\Controller\\PasswordResetController::reset'], ['token'], null, null, false, true, null]],
        666 => [
            [['_route' => 'test_ovh_redirections', '_controller' => 'App\\Controller\\TestOvhRedirectionController::testList'], ['domain'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
